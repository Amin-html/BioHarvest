import sys
import os
sys.path.insert(0, os.getcwd())

from logging.config import fileConfig
from sqlalchemy import pool
from sqlalchemy.ext.asyncio import async_engine_from_config
from alembic import context

from app.db.base import Base
from app.models.product import Product
from app.models.product_image import ProductImage
from app.models.wishlist_item import WishlistItem
from app.models.review import Review
from app.models.address import Address
from app.models.category import Category
from app.models.stock import Stock
from app.core.config import settings
from app.models.user import User
from app.models.refresh_token import RefreshToken
from app.models.cart_item import CartItem
from app.models.cart import Cart
from app.models.order import Order
from app.models.order_item import OrderItem
from app.models.order_status_history import OrderStatusHistory
from app.models.delivery_zone import DeliveryZone
from app.models.delivery_method import DeliveryMethod
from app.models.promo_code import PromoCode
from app.models.notification import Notification

config = context.config
config.set_main_option("sqlalchemy.url", settings.database_url)
#
# if config.config_file_name is not None:
#     fileConfig(config.config_file_name)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection):
    context.configure(connection=connection, target_metadata=target_metadata)
    with context.begin_transaction():
        context.run_migrations()


async def run_async_migrations():
    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)
    await connectable.dispose()


def run_migrations_online() -> None:
    import asyncio
    asyncio.run(run_async_migrations())


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()