from datetime import datetime
from pydantic import BaseModel, ConfigDict

class OrderStatusUpdateIn(BaseModel):
    status: str  # "AWAITING_DELIVERY" | "DELIVERED" | "CANCELLED"

class OrderItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    product_id: int
    product_name_snapshot: str
    unit_price_snapshot: float
    quantity: int
    line_total: float

class OrderOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    user_id: int
    status: str
    subtotal: float
    total: float
    delivery_method_id: int | None
    delivery_price: float
    delivery_address: str | None = None
    created_at: datetime
    items: list[OrderItemOut]
    promo_code_id: int | None
    discount_total: float