from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.core.security_headers import SecurityHeadersMiddleware
from app.api.v1.products import router as products_router
from app.api.v1.category import router as category_router
from app.api.v1.auth import router as authorization_router
from app.api.v1.cart import router as cart_router
from app.api.v1.delivery import router as delivery_router
from app.api.v1.stock import router as stock_router
from app.api.v1.orders import router as order_router, admin_router as admin_orders_router
from app.api.v1.notifications import router as notification_router
from app.api.v1.wishlist import router as wishlist_router
from app.api.v1.reviews import router as reviews_router, admin_router as admin_reviews_router
from app.api.v1.dashboard import router as dashboard_router
from app.api.v1.addresses import router as addresses_router


app = FastAPI(title="BioHarvest")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins_list,
    allow_credentials=True,   # обязательно для httpOnly refresh-cookie
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(SecurityHeadersMiddleware)

app.include_router(products_router, prefix="/api/v1")
app.include_router(category_router, prefix="/api/v1")
app.include_router(authorization_router, prefix="/api/v1")
app.include_router(cart_router, prefix="/api/v1")
app.include_router(order_router, prefix="/api/v1")
app.include_router(delivery_router, prefix="/api/v1")
app.include_router(stock_router, prefix="/api/v1")
app.include_router(admin_orders_router, prefix="/api/v1")
app.include_router(notification_router, prefix="/api/v1")
app.include_router(wishlist_router, prefix="/api/v1")
app.include_router(reviews_router, prefix="/api/v1")
app.include_router(admin_reviews_router, prefix="/api/v1")
app.include_router(dashboard_router, prefix="/api/v1")
app.include_router(addresses_router, prefix="/api/v1")

@app.get("/health/")
async def health():
    return {
        "status": "ok"
    }