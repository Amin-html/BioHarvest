import { Routes, Route } from 'react-router-dom'
import { Layout } from './components/Layout'
import { ProtectedRoute } from './components/ProtectedRoute'
import { AdminLayout } from './components/AdminNav'
import { LoginPage } from './pages/Login'
import { RegisterPage } from './pages/Register'
import { CatalogPage } from './pages/Catalog'
import { ProductDetailsPage } from './pages/ProductDetails'
import { CartPage } from './pages/Cart'
import { CheckoutPage } from './pages/Checkout'
import { OrdersPage } from './pages/Orders'
import { OrderDetailsPage } from './pages/OrderDetails'
import { NotificationsPage } from './pages/Notifications'
import { AdminProductsPage } from './pages/admin/AdminProducts'
import { AdminCategoriesPage } from './pages/admin/AdminCategories'
import { AdminOrdersPage } from './pages/admin/AdminOrders'
import { AdminStockPage } from './pages/admin/AdminStock'
import { AdminReviewsPage } from './pages/admin/AdminReviews'
import { AdminDashboardPage } from './pages/admin/AdminDashboard'
import { WishlistPage } from './pages/Wishlist'
import { ProfilePage } from './pages/Profile'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<CatalogPage />} />
        <Route path="/catalog" element={<CatalogPage />} />
        <Route path="/products/:slug" element={<ProductDetailsPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />

        <Route element={<ProtectedRoute />}>
          <Route path="/cart" element={<CartPage />} />
          <Route path="/checkout" element={<CheckoutPage />} />
          <Route path="/orders" element={<OrdersPage />} />
          <Route path="/orders/:id" element={<OrderDetailsPage />} />
          <Route path="/notifications" element={<NotificationsPage />} />
          <Route path="/wishlist" element={<WishlistPage />} />
          <Route path="/profile" element={<ProfilePage />} />
        </Route>

        <Route element={<ProtectedRoute roles={['ADMIN', 'STAFF']} />}>
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<AdminDashboardPage />} />
            <Route path="products" element={<AdminProductsPage />} />
            <Route path="categories" element={<AdminCategoriesPage />} />
            <Route path="orders" element={<AdminOrdersPage />} />
            <Route path="stock" element={<AdminStockPage />} />
            <Route path="reviews" element={<AdminReviewsPage />} />
          </Route>
        </Route>

        <Route path="*" element={<p className="text-gray-500">Страница не найдена.</p>} />
      </Route>
    </Routes>
  )
}